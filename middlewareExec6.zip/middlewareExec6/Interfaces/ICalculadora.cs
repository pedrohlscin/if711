﻿using System;
using System.Collections.Generic;
using System.Text;

namespace middlewareExec6.Proxies
{
    interface ICalculadora
    {
        public int Eval(String text);
    }
}
