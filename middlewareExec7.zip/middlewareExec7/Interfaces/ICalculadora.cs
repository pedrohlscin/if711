﻿using System;
using System.Collections.Generic;
using System.Text;

namespace middlewareExec7.Proxies
{
    interface ICalculadora
    {
        public int Eval(String text);
    }
}
